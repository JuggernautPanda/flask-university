#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  ArduinoParser.py
#  
#  Copyright 2019  <pi@raspberrypi>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  python3 ArduinoParser.py pHValue
import serial
import atexit,re , json, sys
import paho.mqtt.publish as publish
import time

values = []
serialArduino = serial.Serial('/dev/ttyUSB0', 9600)

def doAtExit():
    serialArduino.close()
    print("Close serial")
    print("serialArduino.isOpen() = " + str(serialArduino.isOpen()))

atexit.register(doAtExit)
print("serialArduino.isOpen() = " + str(serialArduino.isOpen()))
sensorName = sys.argv[1]
print (sensorName)
start_Time = time.time() 
#print (sensorName)
while (True):
    while (serialArduino.inWaiting()==0):
        pass

    valueRead = serialArduino.readline(500)
    valueRead = json.loads(valueRead)
    sensorVal= ((valueRead["data"][sensorName]))
    publish.single(sensorName,sensorVal,0,hostname="localhost")
    time.sleep(1)
    if time.time() - start_Time > 30:
        print ("Timeout")
        break
    #print ((valueRead["data"]['waterLevel']))
    #print ((valueRead["data"]['turbidityValue']))

