#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  flask_ex.py
#  
#  Copyright 2019  <pi@raspberrypi>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  

import RPi.GPIO as GPIO
from flask import Flask, render_template, request, Response, jsonify
from datetime import datetime
import sys,time
from camera_pi import Camera
import subprocess,re
from subprocess import Popen, PIPE
import paho.mqtt.subscribe as subscribe
import Adafruit_DHT
app = Flask(__name__)

ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
ipaddR = (ip.communicate()[0])
ipaddR = ipaddR.decode("utf-8")
ipaddR = ipaddR.strip()
print (ipaddR)
sensor = "nope"
val = "nope"
action = "nope"
GPIO.setmode(GPIO.BCM)
# Create a dictionary called pins to store the pin number, name, and pin state:
pins = {
   20 : {'name' : 'GPIO 20', 'state' : GPIO.LOW},
   21 : {'name' : 'GPIO 21', 'state' : GPIO.LOW}
   }

# Set each pin as an output and make it low:
for pin in pins:
   GPIO.setup(pin, GPIO.OUT)
   GPIO.output(pin, GPIO.LOW)

@app.route('/video')
def video():
    """Video streaming home page."""
    return render_template('video.html')
def gen(camera):
    """Video streaming generator function."""
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/pH')
def pH():
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('pH.html',**templateData)

@app.route('/turbidity')
def turbudity():
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('turbidity.html',**templateData)
    
@app.route('/water')
def water():
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('water.html',**templateData)

@app.route('/startpH')
def startpH():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/ArduinoParser.py","pHValue","&"])
    return jsonify({'message':'Finished'})

@app.route('/startturbidity')
def startturbidity():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/ArduinoParser.py","turbidityValue","&"])
    return jsonify({'message':'Finished'})

@app.route('/startwaterLevel')
def startwaterLevel ():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/ArduinoParser.py","waterLevel","&"])
    return jsonify({'message':'Finished'})


@app.route('/startMeasurement')
def startMeasurement():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/distanceUltraSoundMQTT.py","&"])
    return jsonify({'message':'Finished'})

@app.route('/iftttUS')
def iftttUS():
    r = subprocess.call(["raspistill","-o","/home/pi/web-server/static/Toncy.jpeg"])
    return render_template('showImage.html')

@app.route('/Distance')
def distance():
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('UltraSound.html', **templateData)

@app.route('/startLightMeasurement')
def startLightMeasurement():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/LDR.py","&"])
    time.sleep(2)
    return jsonify({'message':'Finished'})

@app.route('/light')
def light():
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('light.html', **templateData)

@app.route('/ifttt')
def ifttt():
    #print (ipaddR)
    ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
    ipaddR = (ip.communicate()[0])
    ipaddR = ipaddR.decode("utf-8")
    ipaddR = ipaddR.strip()
    templateData = {
      'ip' : ipaddR
   }
    return render_template('ifttt.html', **templateData)


@app.route('/iftttsubmit',methods=['POST','GET'])
def iftttsubmit():
    
    if request.method == "POST":
       selection = request.form
       global action,sensor, val
       action = str(selection.get('action'))
       sensor = str(selection.get('sensor'))
       val = str(selection.get('val'))
       print (action)
       print (sensor)
       print (val)
       topics = ['World','fanStatus']
       ip = subprocess.Popen(["/home/pi/web-server/findIp.sh","&"], stdout=subprocess.PIPE)
       ipaddR = (ip.communicate()[0])
       ipaddR = ipaddR.decode("utf-8")
       ipaddR = ipaddR.strip()
       templateData = {
      'ip' : ipaddR
   }
       
       if (sensor ==  "ultrasound" and val == "on" and action == "camera"):
          print ("camera action taken")
          r = subprocess.call(["sudo","python3","/home/pi/web-server/distanceUltraSoundIFTTT.py","&"]) 
       if(sensor == "light" and val == "on" and action == "LED"):
          print ("action taken")
          #start_Time = time.time()
          
          r = subprocess.call(["sudo","python3","/home/pi/web-server/LDR.py","&"])
          
          """
          while True:
             print ("waiting")
             m = subscribe.simple(topics, hostname="raspberrypi", retained=False, msg_count=1)
             for a in m:
                print (a.payload)
                if (str(a.payload) == "0"):
                   print ("LED on")
                   break
                if time.time() - start_Time > 10:
                   print ("Time out")
                   break
          """   
    return render_template('ifttt.html', **templateData)

@app.route("/LED")
def LED():
   # For each pin, read the pin state and store it in the pins dictionary:
   for pin in pins:
      pins[pin]['state'] = GPIO.input(pin)
   # Put the pin dictionary into the template data dictionary:
   templateData = {
      'pins' : pins
      }
   # Pass the template data into the template main.html and return it to the user
   return render_template('main.html', **templateData)

# The function below is executed when someone requests a URL with the pin number and action in it:
@app.route("/iftttLED/<changePin>/<action>")
def iftttLED(changePin, action):
   # Convert the pin from the URL into an integer:
   changePin = int(changePin)
   # Get the device name for the pin being changed:
   deviceName = pins[changePin]['name']
   # If the action part of the URL is "on," execute the code indented below:
   if action == "on":
      # Set the pin high:
      GPIO.output(changePin, GPIO.HIGH)
      # Save the status message to be passed into the template:
      message = "Turned " + deviceName + " on."
   if action == "off":
      GPIO.output(changePin, GPIO.LOW)
      message = "Turned " + deviceName + " off."

   # For each pin, read the pin state and store it in the pins dictionary:
   for pin in pins:
      pins[pin]['state'] = GPIO.input(pin)

   # Along with the pin dictionary, put the message into the template data dictionary:
   templateData = {
      'pins' : pins,
      'ip' : ipaddR
   }

   return render_template('ifttt.html', **templateData)


# The function below is executed when someone requests a URL with the pin number and action in it:
@app.route("/<changePin>/<action>")
def action(changePin, action):
   # Convert the pin from the URL into an integer:
   changePin = int(changePin)
   # Get the device name for the pin being changed:
   deviceName = pins[changePin]['name']
   # If the action part of the URL is "on," execute the code indented below:
   if action == "on":
      # Set the pin high:
      GPIO.output(changePin, GPIO.HIGH)
      # Save the status message to be passed into the template:
      message = "Turned " + deviceName + " on."
   if action == "off":
      GPIO.output(changePin, GPIO.LOW)
      message = "Turned " + deviceName + " off."

   # For each pin, read the pin state and store it in the pins dictionary:
   for pin in pins:
      pins[pin]['state'] = GPIO.input(pin)

   # Along with the pin dictionary, put the message into the template data dictionary:
   templateData = {
      'pins' : pins
   }

   return render_template('main.html', **templateData)

@app.route('/startSoilMoisture')
def startSoilMoisture():
    r = subprocess.call(["sudo","python3","/home/pi/web-server/soilMoisture.py","&"])
    return jsonify({'message':'Finished'})
    
@app.route('/moisture')
def moisture():
    return render_template('moisture.html')

@app.route("/temperature")
def humidity():
   humidity, temperature = Adafruit_DHT.read_retry(11, 4)
   date = datetime.now()
   #date = datetime.strptime('Mon Jun 28 10:51:07 2010', '%a %b %d %H:%M:%S %Y')
   templateData = {
      'humidity' : humidity,
      'temperature' : temperature,
      'date' : date
   }
   return render_template('DHT2.html', **templateData)

@app.route("/")
def main():
   return render_template('index.html')


if __name__ == "__main__":
   app.run(host='0.0.0.0', port=800, debug=True, threaded=True)
