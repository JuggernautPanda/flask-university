#!/bin/bash
now=`ifconfig wlan0 | grep "inet " | awk -F'[: ]+' '{ print $3 }'`
echo "$now"
