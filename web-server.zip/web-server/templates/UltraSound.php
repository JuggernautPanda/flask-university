<!--
   UltraSound.html
   
   Copyright 2019 root <root@raspberrypi>
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.
   
   
-->

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title><?php echo "PwC" ?> UltraSound</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/paho-mqtt/1.0.1/mqttws31.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/paho-mqtt/1.0.1/mqttws31.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="{{url_for('static', filename='circleDonutChart.js')}}"></script>
        <script>
            var circle = new circleDonutChart('example');
            circle.draw({
                end: 75,
                start: 0,
                maxValue: 500,
                unitText: '',
                titlePosition: "outer-top",
                titleText: "Sensor Readings in CMS",
                outerCircleColor: '#0085c8',
                innerCircleColor: '#909081'
            });
        </script>
        <script type="text/javascript">
            // Create a client instance
            var clientId= "clientid" +  Math.floor(1000*Math.random());
            console.log(clientId);
            client = new Paho.MQTT.Client("localhost", 1884, clientId);


// set callback handlers
            client.onConnectionLost = onConnectionLost;
            client.onMessageArrived = onMessageArrived;

// connect the client
            client.connect({onSuccess: onConnect});


// called when the client connects
            function onConnect() {
                // Once a connection has been made, make a subscription and send a message.
                console.log("onConnect");
                client.subscribe("World");

                message = new Paho.MQTT.Message("Hello");
                message.destinationName = "World";
                client.send(message);
            }

// called when the client loses its connection
            function onConnectionLost(responseObject) {
                if (responseObject.errorCode !== 0) {
                    console.log("onConnectionLost:" + responseObject.errorMessage);
                }
            }

// called when a message arrives
            function onMessageArrived(message) {
               
                console.log("onMessageArrived:" + message.payloadString);
               
                circle.draw( {end:message.payloadString, unitText:'', maxValue:20} );
                console.log("OnParse:" + message.payloadString);
              
                
            }

            function onSubmit() {

                console.log(document.getElementById("topicsub").value);
                subtopic = document.getElementById("topicsub").value;
                client.subscribe(subtopic);
            }
            
            function onPublish() {

                message = new Paho.MQTT.Message(document.getElementById("pubmsg").value);
                message.destinationName = document.getElementById("topicpub").value;
                client.send(message);
            }
        </script>
        

    </head>

    <body>
    
        <div align="center">
            <h1 align="center">PwC UltraSound MQTT</h1>
           <!-- <label for="topicsub" >Topic Subscribe</label>
            <input type="textbox" id="topicsub">
           
            <button id="submit" value="Submit" onclick="onSubmit()">Submit</button> -->
        </div>
        <br>
       
        <div id="example" align="center"></div>
        <br><br>
        <div align="center">
            <label for="topicpub" >Topic Publish</label>
            <input type="textbox" id="topicpub"><br><br>
            <label for="pubmsg" >Message</label>
            <input type="textbox" id="pubmsg" size="35">
            <button onclick="onPublish()">Publish</button>   
        </div>
    
</html>
